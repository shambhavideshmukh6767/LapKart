from django.urls import path
from . import views


urlpatterns = [
    path("test/", views.test_view),
    path("show/", views.show_laptops_view),
    path("add/", views.add_laptops_view),
    path("update/<i>/", views.update_laptops_view),
    path("delete/<i>/", views.delete_laptops_view),
]