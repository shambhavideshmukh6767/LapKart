from django.shortcuts import render, redirect
from .models import Laptop
from .forms import LaptopModelForm


# Create your views here.
def test_view(request):
    template_name = "LaptopsAPP/layout.html"
    context = {}
    return render(request, template_name, context)


def show_laptops_view(request):
    qs_of_laptops = Laptop.objects.all()
    template_name = "LaptopsAPP/show_laptops.html"
    context = {"qs_of_laptops":qs_of_laptops}
    return render(request, template_name, context)


def add_laptops_view(request):
    form = LaptopModelForm()
    if request.method == "POST":
        form = LaptopModelForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/laptops/show/")
    template_name = "LaptopsAPP/add_laptops.html"
    context = {"form":form}
    return render(request, template_name, context)
    #GET - 21,  27,28,29
    #POST with valid data-  21,22,23,24,25,26
    #POST with InValid data-  21,22,23,  27,28,29


def update_laptops_view(request,i):
    lap_obj = Laptop.objects.get(id=i)
    form = LaptopModelForm(instance=lap_obj)
    if request.method == "POST":
        form = LaptopModelForm(request.POST,instance=lap_obj)
        if form.is_valid():
            form.save()
            return redirect("/laptops/show/")
    template_name = "LaptopsAPP/add_laptops.html"
    context = {"form":form}
    return render(request, template_name, context)


def delete_laptops_view(request,i):
    lap_obj = Laptop.objects.get(id=i)
    lap_obj.delete()
    return redirect("/laptops/show/")