from django.db import models


# Create your models here.
class Laptop(models.Model):
    company = models.CharField(max_length=32)
    variant = models.CharField(max_length=32)
    ram = models.IntegerField()
    rom = models.IntegerField()
    price = models.FloatField()