from django.db import models


# Create your models here.
class SmartphoneModel(models.Model):
    company = models.CharField(max_length=32)
    variant = models.CharField(max_length=32)
    camera = models.CharField(max_length=32)
    processor = models.CharField(max_length=32)
    operating_sys = models.CharField(max_length=32)
    ram = models.IntegerField()
    rom = models.IntegerField()
    price = models.FloatField()