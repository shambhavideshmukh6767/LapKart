from django.apps import AppConfig


class SmartphoneappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'SmartphoneAPP'
