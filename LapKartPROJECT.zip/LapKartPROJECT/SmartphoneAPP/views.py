from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from .models import SmartphoneModel
from .forms import SmartphoneModelForm


# Create your views here.
def test_view(request):
    template_name = "SmartphoneAPP/layout.html"
    context = {}
    return render(request, template_name, context)


def show_smartphones_view(request):
    smartphone_objs = SmartphoneModel.objects.all()
    template_name = "SmartphoneAPP/show_smartphones.html"
    context = {"smartphone_objs":smartphone_objs}
    return render(request, template_name, context)


def add_smartphone_view(request):
    form = SmartphoneModelForm()
    if request.method == "POST":
        form = SmartphoneModelForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/smartphones/show/")
    template_name = "SmartphoneAPP/add_smartphone.html"
    context = {"form":form}
    return render(request, template_name, context)


def update_smartphone_view(request,i):
    smartphone = SmartphoneModel.objects.get(id=i)
    form = SmartphoneModelForm(instance=smartphone)
    if request.method == "POST":
        form = SmartphoneModelForm(request.POST,instance=smartphone)
        if form.is_valid():
            form.save()
            return redirect("/smartphones/show/")
    template_name = "SmartphoneAPP/add_smartphone.html"
    context = {"form":form}
    return render(request, template_name, context)

@login_required(login_url='/auth/login/')
def delete_smartphone_view(request,i):
    smartphone = SmartphoneModel.objects.get(id=i)
    smartphone.delete()
    return redirect("/smartphones/show/")
