from django import forms
from .models import SmartphoneModel


class SmartphoneModelForm(forms.ModelForm):
    class Meta:
        model = SmartphoneModel
        fields = '__all__'